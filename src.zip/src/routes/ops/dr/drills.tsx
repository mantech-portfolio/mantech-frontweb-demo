import { createFileRoute } from '@tanstack/react-router'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export const Route = createFileRoute('/ops/dr/drills')({
    component: DrillsPage,
})

function DrillsPage() {
    return (
        <div className="p-6 space-y-6">
            <h1 className="text-2xl font-semibold">DR 훈련 이력</h1>

            <Card>
                <CardHeader>
                    <CardTitle>최근 DR Drill</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span>2025-01-10 전체 전환 훈련</span>
                        <Badge className="bg-green-600">PASS</Badge>
                    </div>
                    <div className="flex justify-between">
                        <span>2024-12-01 부분 복구 훈련</span>
                        <Badge className="bg-green-600">PASS</Badge>
                    </div>
                </CardContent>
            </Card>
        </div>
    )
}

import { createFileRoute } from '@tanstack/react-router'
import PageHeader from '@/components/common/PageHeader'
import ErrorState from '@/components/common/ErrorState'
import EmptyState from '@/components/common/EmptyState'
import { Skeleton } from '@/components/ui/skeleton'
import StatusBadge from '@/components/common/StatusBadge'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { useBatchJobsQuery } from '@/queries/it/useBatchQuery'

export const Route = createFileRoute('/ops/it/batch')({
  component: BatchPage,
})

function BatchPage() {
  const query = useBatchJobsQuery()

  if (query.isError) return <ErrorState />

  return (
    <div className="space-y-6">
      <PageHeader
        title="배치 작업 관리"
        description="배치 작업 상태 및 실행 정보를 확인합니다."
      />

      {query.isLoading
        ? Array.from({ length: 2 }).map((_, i) => (
          <Skeleton key={i} className="h-32" />
        ))
        : !query.data || query.data.length === 0 ? (
          <EmptyState description="등록된 배치가 없습니다." />
        ) : (
          query.data.map((job) => (
            <Card key={job.name}>
              <CardHeader>
                <CardTitle className="text-base">{job.name}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <Row label="실행 주기" value={job.cron} />
                <Row label="최근 실행" value={job.lastRun} />
                <Row label="평균 소요" value={job.avgDuration} />
                <StatusBadge status={job.status} />
              </CardContent>
            </Card>
          ))
        )}
    </div>
  )
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span>{value}</span>
    </div>
  )
}

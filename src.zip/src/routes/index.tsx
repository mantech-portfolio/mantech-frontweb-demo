import { createFileRoute, Link } from '@tanstack/react-router'
import PageHeader from '@/components/common/PageHeader'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { ServerCog, ShieldAlert } from 'lucide-react'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="운영 콘솔 홈"
        description="운영 자동화와 재해 복구 기능을 한 화면에서 관리합니다."
      />

      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <GuideCard
          icon={<ServerCog size={20} />}
          title="MDRM-IT"
          description="배치, 배포, 헬스체크, 운영 Workflow 관리"
          to="/ops/it/dashboard"
        />
        <GuideCard
          icon={<ShieldAlert size={20} />}
          title="MDRM-DR"
          description="재해 복구 시나리오, RPO/RTO 지표 관리"
          to="/ops/dr/overview"
        />
      </section>
    </div>
  )
}

function GuideCard({
  icon,
  title,
  description,
  to,
}: {
  icon: React.ReactNode
  title: string
  description: string
  to: string
}) {
  return (
    <Link to={to}>
      <Card className="hover:bg-accent transition">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-base">
            {icon}
            {title}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground">
          {description}
        </CardContent>
      </Card>
    </Link>
  )
}
